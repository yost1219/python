"""
Author: Yost
Title: Python Test Part 1
Date: 9 Oct 2018
"""


#!/usr/bin/env python

import os, glob, subprocess

"""
# Given a list of strings (['string1', 'string2', 'string3']), reverse all of the characters, and
# join them all together into a single string, with each previous word separated by spaces
# (the above example becomes '1gnirts 2gnirts 3gnirts')
"""
def first_test(string_list):
#iterate through all items of list
    for x in range(0,len(string_list)):
#put string in buffer
        temp=string_list[x]
#reverse string
        temp=temp[::-1]
#replace old string with reversed string
        string_list[x]=temp
#join strings into single string
    strings=" ".join(string_list)
#return new string
    return strings

"""
# Given a directory path, find each file that ends with '.txt', and create a dictionary,
# where each element consists of the filename, and its contents (e.g., if we had a file called
# "foo.txt" that contained "AAAA", our dictionary would look like: 
# { "evalFolder\\foo.txt" : "AAAA" }). This dictionary will be our return item.
"""
def third_test(fname):  #C:\Users\Student\Desktop\evalFolder
#change directory to fname location
    os.chdir(fname)
#create empty dictionary
    dict={}
#open folder location
#check each file
    for filename in os.listdir(fname):
#if file is .txt, save its name and contents in dictionary
        if filename.endswith(".txt"):
            file=open(filename,'r')
            data=file.read()
            dict[filename]=data
#close file when done
            file.close()
#return dictionary
	return dict